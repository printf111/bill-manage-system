#pragma once
//����ˣ� hlju-24-xsd
//VectorBillStorage.h
#include <vector>
#include <string>
#include "BillStorage.h"
class VectorBillStorage : public BillStorage {// ʹ�� std::vector �洢�˵�����
public:
    void addBill(const Bill& bill) override;  
    void changeBill(int ID, Bill other) override;
    void remove(int ID) override;
    const std::vector<Bill>& getAllBills() const override;

    const std::vector<Bill>& findBillsByDate(const std::string& date) const override;
    const std::vector<Bill>& findBillsByTime(const std::string& Time) const override;
    const std::vector<Bill>& findBillsByID(int l, int r) const override;
    void printAllBill() const override;
    int size() override;

private:
    std::vector<Bill> bills;
    mutable std::vector<Bill> filteredBills;   // ���ڴ洢ɸѡ����ĳ�Ա����


};
