#pragma once
//����ˣ� hlju-24-xsd
//BillStorage.h
#include <vector>
#include <string>
#include "Bill.h"

class BillStorage {// ����洢��
public:
    virtual void addBill(const Bill& bill) = 0;
    virtual void changeBill(int ID, Bill other) = 0;
    virtual void remove(int ID) = 0;
    virtual const std::vector<Bill>& getAllBills() const = 0;
    virtual const std::vector<Bill>& findBillsByDate(const std::string& date) const = 0;
    virtual const std::vector<Bill>& findBillsByTime(const std::string& date) const = 0 ;
    virtual const std::vector<Bill>& findBillsByID(int l, int r) const = 0;
    virtual int size() = 0;
    virtual void printAllBill() const =0;
    virtual ~BillStorage() {}
};
