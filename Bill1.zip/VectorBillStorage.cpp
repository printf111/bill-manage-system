//VectorBillStorage.cpp
//����ˣ� hlju-24-xsd
#include "VectorBillStorage.h"
void VectorBillStorage::addBill(const Bill& bill) {
    bills.push_back(bill);
}

const std::vector<Bill>& VectorBillStorage::getAllBills() const {
    return bills;
}

void VectorBillStorage::changeBill(int ID, Bill other)
{
    bills[ID - 1] = other;
}

void VectorBillStorage::remove(int ID)
{
    auto it = bills.begin() + ID - 1;
    it=bills.erase(it);
    while (it != bills.end())
    {
        it++->setId(ID++);
    }
}

const std::vector<Bill>& VectorBillStorage::findBillsByDate(const std::string& date) const {
    // ���֮ǰ��ɸѡ���
    filteredBills.clear();
    for (const auto& bill : bills) {
        if (bill.getDate() == date) {
            filteredBills.push_back(bill);
        }
    }
    return filteredBills;
}
const std::vector<Bill>& VectorBillStorage::findBillsByTime(const std::string& Time) const {
    // ���֮ǰ��ɸѡ���
    filteredBills.clear();
    for (const auto& bill : bills) {
        if (bill.getTime() == Time) {
            filteredBills.push_back(bill);
        }
    }
    return filteredBills;
}
const std::vector<Bill>& VectorBillStorage::findBillsByID(int l,int r) const
{
    filteredBills.clear();
    int id;
    for (const auto& bill : bills) {
        id = bill.getID();
        if (id >=l && id<=r ) {
            filteredBills.push_back(bill);
        }
    }
    return filteredBills;
}
void VectorBillStorage::printAllBill() const 
{
    size_t number = bills.size();
    for (int i = 0;i < number;i++)
    {
        std::cout << bills.at(i) << std::endl;
    }
}

int VectorBillStorage::size()
{
    return (int)this->bills.size();//�����ǲ�̫���ܳ���int���ͣ���ǿת�ᾯ��
}

